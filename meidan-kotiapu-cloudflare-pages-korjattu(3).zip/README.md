# Meidän Kotiapu – Cloudflare Pages -julkaisu

Tämä on GitHub-julkaisuun tarkoitettu **projektin juurikansio**. Sivusto on kansiossa `public/`, ja palvelinpuolen Pages Functions -reitit ovat kansiossa `functions/`.

## Miksi virhe tuli?
Cloudflaren hallintapaneelin **Direct Upload / drag-and-drop** ei julkaise `functions/`-hakemiston lähdekoodia Pages Functions -toimintoina. Pelkän ZIP-tiedoston tai `public/`-kansion lataus ei siis riitä toimivalle ajanvaraukselle.

## Suositeltu tapa: GitHub + Cloudflare Pages
1. Pura ZIP. Luo GitHubissa uusi repository ja siirrä **projektikansion sisältö** sen juureen: `public/`, `functions/`, `schema.sql` ja `README.md`. Älä siirrä vain `public/`-kansiota.
2. Cloudflare Dashboard → Workers & Pages → Create → Pages → **Connect to Git**. Valitse GitHub-repository. Jos Pages-valinta ei näy, etsi Pages-projektin luonti Workers & Pages -näkymästä.
3. Build command: **tyhjä**. Build output directory: **`public`**. Root directory: projektin juuri. Julkaise.
4. Cloudflare → D1 → Create database, nimeksi esim. `meidan-kotiapu-db`. Avaa tietokannan SQL Console ja suorita `schema.sql`-tiedoston SQL-lauseet.
5. Pages-projekti → Settings → Bindings → Add → D1 database. Variable name **`DB`**, database: `meidan-kotiapu-db`. Tallenna ja tee **uusi deployment**. Cloudflaren hallintapaneelin otsikot voivat vaihdella.
6. Testaa `https://OMA-SIVUSTO.pages.dev/api/availability?date=2026-11-17`: onnistunut vastaus on JSON kuten `{"bookings":[]}`. Jos näkyy `Tietokantaa ei ole yhdistetty`, tarkista DB-binding ja tee uusi deployment. Jos näkyy HTML/404, Functions ei ole julkaistu.
7. Testaa varaus kahdella selaimella: samaa aikaa ei saa voida varata kahdesti. Tarkista myös 20 minuutin siirtymäväli.

**Huom.** GitHubiin ei tarvitse laittaa tietokannan tunnuksia tai asiakastietoja. `schema.sql` sisältää vain tietokannan rakenteen.

## Vaihtoehtoinen julkaisu: Wrangler CLI
Jos käytät komentoriviä ja olet projektin juuressa: `npx wrangler login` ja `npx wrangler pages deploy public --project-name=OMA-PAGES-PROJEKTI`. Wrangler osaa julkaista `functions/`-kansion lähdekoodista. Luo ja sido D1-tietokanta erikseen kuten yllä. Dashboardin drag-and-drop ei vastaa tätä komentoa.

## Varauslogiikka
- Ma–pe klo 08–16, varauksen kesto 60–480 min, aloitukset 20 minuutin välein.
- Varausten väliin 20 minuutin siirtymävara.
- Yksi työntekijän kalenteri. Varaukset tallentuvat `pending`-tilaan ja estävät päällekkäisyydet.
- Kaikki palvelut ja lastenhoito ovat mukana. Muiden aikojen ja urakoiden kyselyt tallentuvat `inquiries`-tauluun.

## Ennen julkista asiakaskäyttöä
Tämä on toiminnallinen pohja, ei vielä valmis tuotantopalvelu. Lisää yrityksen oikeat yhteystiedot, toiminta-alue, hinnat, tietosuojaseloste, roskapostisuojaus, suojattu varausten hallinta, vahvistus- ja peruutusprosessi sekä sähköposti-ilmoitukset. Lastenhoidon käytännöt ja henkilöstön soveltuvuus on varmistettava erikseen. Älä kerää arkaluonteisia tietoja vapaatekstikenttiin.

## Ulkoasu
Lämmin sininen `#315A80`, salvianvihreä `#A9BEA9` ja vaalea tausta `#F5F8F4`. Ei punertavaa korostusväriä.
